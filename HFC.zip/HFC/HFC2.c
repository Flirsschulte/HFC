/***********************************************************************************************
 *
 * MATLAB:  mem1 = Detection1(A);
 * 
 * 
 *
 *  Stefan Schulte (stefan.schulte@Ugent.be)
 *  Last modified: 30/05/06
 *
 ************************************************************************************************/

#include "mex.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
//   printf("\t%d %s %f %s %c\n", x, str, pi, "WOW", c);


double LARGE (double x, double p1, double p2) {
   double res = 0.0;
   if ((x > p1) && (x < p2))   res = (x-p1)/(p2-p1);
   else if (x > p2)            res = 1.0;
   else                        res = 0.0;
   return res;
}



double absol(double a) {
   double b;
   if(a<0)   b=-a;
   else   b=a;
   return b;
}

double minimum(double a, double b) {
   double ret = 0;
   if(a <= b)   ret = a;
   else   ret = b;
   return ret;
}

double maximum(double a, double b) {
   double ret = 0;
   if(a >= b)   ret = a;
   else   ret = b;
   return ret;
}


double MHAF(double x, double a, double b, double c, int cas, double h1, double h2) {
   double mem = 0, res = 0;
   mem = minimum((1.0-h1),(1.0-h2));   
   res = 1.0/(1.0 + pow(((x-c)/a),(2.0*b))); 
  if (cas ==1)
     if (x <= c) res = 1.0;
  if (cas ==2)
	 if (x >= c) res = 1.0;
   return (mem*res);
}

double MHAF2(double x, double a, double b, double c, int cas, double h) {
   double mem = 0, res = 0;
   mem = (1.0-h);   
   
   res = 1.0/(1.0 + pow(((x-c)/a),(2.0*b))); 
   if (cas ==1)
      if (x <= c) res = 1.0;
   if (cas ==2)
	  if (x >= c) res = 1.0;
   return (mem*res);
}      
        
void DetectionHFC2 (double **out, double **in1, double **in2, int M, int N, int W) {
   int i,j,k,l, loop;   
   double **geg, *med;
   
   double pos, tel = 0, neg;
   double hlp = 0, sign = 0, tmp = 0;
  
   int rand1a = 0;
   int rand1b = 0;
   int rand2a = 0;
   int rand2b = 0;
               
   med = malloc((2*W+1)*(2*W+1)*sizeof(double));
   
   geg = malloc(M*sizeof(double));
   for(i=0;i<M;i++)
      geg[i] = malloc(N*sizeof(double));

      
   for(i=0; i<M; i++){
      for(j=0; j<N; j++){
         geg[i][j] = (in1[i][j] - in2[i][j] + 255.0)/2.0;
      }
   }
      
   for(i=0; i<M; i++){
      for(j=0; j<N; j++){
         /* step 1. Determine the local window*/      
         if(i < W) {
            rand1a = i;
            rand1b = W;
         }
         else {
              if (i>M-W-1){
               rand1a = W;
               rand1b = M-i-1;
            }
            else{
               rand1a = W;
               rand1b = W;
            }
         }

         
         if(j < W) {
            rand2a = j;
            rand2b = W;
         }
         else {
            if (j > N-W-1){
               rand2a = W;
               rand2b = N-j-1;
            }
            else{
               rand2a = W;
               rand2b = W;
            }
         }
         /* end step 1. */      
         
         pos = 0.0; neg = 0.0;
         for (k=i-rand1a; k<=i+rand1b; k++){
	        for (l=j-rand2a; l<=j+rand2b; l++){
	           if (geg[k][l] > 0) pos++;
	           if (geg[k][l] < 0) neg++;
            }
         }
         
         if (pos > neg) sign = +1;
         else sign = -1;
         
         
         tel = 0.0;
         for (k=i-rand1a; k<=i+rand1b; k++){
	        for (l=j-rand2a; l<=j+rand2b; l++){
	           tmp = geg[k][l];
	           if (tmp*sign < 0) continue;
	           for (loop = 0; loop < tel; loop++){
	              if (tmp < med[loop]){
	                 hlp = med[loop];
	                 med[loop] = tmp;
	                 tmp = hlp;
	              }
	           }
	           med[(int)tel] = tmp;
	           tel+=1;
            }
         }
         
         hlp = absol(geg[i][j] - med[(int)(tel/2.0)]);
         if (hlp < 15) out[i][j] = 0;
         else if ((hlp >= 15) && (hlp <= 30))  out[i][j] = (hlp-15.0)/15.0;
         else out[i][j] = 1.0;
         
      }
   }

   for(i=0;i<M;i++)  free(geg[i]);
   free(geg); 
   
   free(med); 
}


/**************************************************************************************
*  The main function for the calculation of the shrinkage method
*
***************************************************************************************/
void callHFC1c(double **A1,double **A2,double **A3,double **noiseR,double **noiseG,double **noiseB,double *out1,double *out2,double *out3,int M, int N,int W) { 
   /* Declaration */
   int i,j,k,l;   
   double **RG, **RB, **GB, somRG = 0, somRB = 0, somGB = 0;
   int rand1a = 0;   int rand1b = 0;   int rand2a = 0;   int rand2b = 0;

   
   double aDkRG = 0.2163, bDkRG = 15, cDkRG = 0.2505;
   double aBrRG = 0.1171, bBrRG = 15, cBrRG = 0.5044;
   double aMdRG = 0.6666, bMdRG = 15, cMdRG = 0.7344;
   
   double aDkRB = 0.2163, bDkRB = 15, cDkRB = 0.2505;
   double aBrRB = 0.1171, bBrRB = 15, cBrRB = 0.5044;
   double aMdRB = 0.6666, bMdRB = 15, cMdRB = 0.7344;
   
   double aDkGB = 0.2163, bDkGB = 15, cDkGB = 0.2505;
   double aBrGB = 0.1171, bBrGB = 15, cBrGB = 0.5044;
   double aMdGB = 0.6666, bMdGB = 15, cMdGB = 0.7344;
   
   double tresR = 0.05, tresG = 0.05, tresB = 0.05;

   double aDkR = 0.2163, bDkR = 15, cDkR = 0.2505;
   double aBrR = 0.1171, bBrR = 15, cBrR = 0.5044;
   double aMdR = 0.6666, bMdR = 15, cMdR = 0.7344;
   
   double aDkG = 0.2163, bDkG = 15, cDkG = 0.2505;
   double aBrG = 0.1171, bBrG = 15, cBrG = 0.5044;
   double aMdG = 0.6666, bMdG = 15, cMdG = 0.7344;
   
   double aDkB = 0.2163, bDkB = 15, cDkB = 0.2505;
   double aBrB = 0.1171, bBrB = 15, cBrB = 0.5044;
   double aMdB = 0.6666, bMdB = 15, cMdB = 0.7344;
   
   double *histRG, *histRB, *histGB;
   double *NhistRG, *NhistRB, *NhistGB;
   double *OhistRG, *OhistRB, *OhistGB;
   double **noiseRG, **noiseRB, **noiseGB;
   
   double minR = 0, minG = 0, minB = 0;
   double maxR = 0, maxG = 0, maxB = 0;
   double minRG = 0, minRB = 0, minGB = 0;
   double maxRG = 0, maxRB = 0, maxGB = 0;

   double tmp = 0, totRG = 0, totRB = 0, totGB = 0;
   double totR = 0, totG = 0, totB = 0;
   double somR = 0, somG = 0, somB = 0;
   double t1 = 0, t2 = 0, t3 = 0, t4 = 0;
   double hlp1 = 0, hlp2 = 0, tel1 = 0, tel2 = 0, tel = 0;
   double min1 = 0, min2 = 0, min3 = 0;
   double resR = 0, resG = 0, resB = 0;
   
      
   double C_DKRG = 0, C_DKRB = 0, C_DKGB = 0; 
   double C_MDRG = 0, C_MDRB = 0, C_MDGB = 0; 
   double C_BRRG = 0, C_BRRB = 0, C_BRGB = 0; 
   
   double mass_DKRG = 0,   mass_BRRG = 0,   mass_MDRG = 0;
   double mass_DKRB = 0,   mass_BRRB = 0,   mass_MDRB = 0;
   double mass_DKGB = 0,   mass_BRGB = 0,   mass_MDGB = 0;

   double HDKRG = 0, HDKRB = 0, HDKGB = 0; 
   double HMDRG = 0, HMDRB = 0, HMDGB = 0; 
   double HBRRG = 0, HBRRB = 0, HBRGB = 0; 
   
   double som_DKRG = 0, som_DKRB = 0, som_DKGB = 0;
   double som_MDRG = 0, som_MDRB = 0, som_MDGB = 0;
   double som_BRRG = 0, som_BRRB = 0, som_BRGB = 0;

   double Sum_DKRG = 0, Sum_DKRB = 0, Sum_DKGB = 0;
   double Sum_MDRG = 0, Sum_MDRB = 0, Sum_MDGB = 0;
   double Sum_BRRG = 0, Sum_BRRB = 0, Sum_BRGB = 0;

   double predRG = 0, predRB = 0, predGB = 0;
   double predGR = 0, predBR = 0, predBG = 0;
   
   /* Memory  Initialization */
                  
   RG = malloc(M*sizeof(double));
   for(i=0;i<M;i++)
      RG[i] = malloc(N*sizeof(double));
   
   RB = malloc(M*sizeof(double));
   for(i=0;i<M;i++)
      RB[i] = malloc(N*sizeof(double));
   
   GB = malloc(M*sizeof(double));
   for(i=0;i<M;i++)
      GB[i] = malloc(N*sizeof(double));
   
   histRG = malloc(512*sizeof(double));
   histRB = malloc(512*sizeof(double));
   histGB = malloc(512*sizeof(double));
   
   NhistRG = malloc(512*sizeof(double));
   NhistRB = malloc(512*sizeof(double));
   NhistGB = malloc(512*sizeof(double));
   
   OhistRG = malloc(512*sizeof(double));
   OhistRB = malloc(512*sizeof(double));
   OhistGB = malloc(512*sizeof(double));
      
   noiseRG = malloc(M*sizeof(double));
   for(i=0;i<M;i++)
      noiseRG[i] = malloc(N*sizeof(double));
   
   noiseRB = malloc(M*sizeof(double));
   for(i=0;i<M;i++)
      noiseRB[i] = malloc(N*sizeof(double));
   
   noiseGB = malloc(M*sizeof(double));
   for(i=0;i<M;i++)
      noiseGB[i] = malloc(N*sizeof(double));
   
      
   for(i=0; i<M; i++){
      for(j=0; j<N; j++){
         RG[i][j] = A1[i][j] - A2[i][j];
         RB[i][j] = A1[i][j] - A3[i][j];
         GB[i][j] = A2[i][j] - A3[i][j];

         noiseRG[i][j] = 1.0;
         noiseRB[i][j] = 1.0;
         noiseGB[i][j] = 1.0;
      }
   }
     
   /*
   *   Calculation of the fuzzy membership degrees in the fuzzy set noise
   *   for each component
   */

   /*
   *   Calculation of the fuzzy membership degrees in the fuzzy set noise
   *   for each colour differences
   */
   DetectionHFC2 (noiseRG, A1, A2, M, N, W);
   DetectionHFC2 (noiseRB, A1, A3, M, N, W);
   DetectionHFC2 (noiseGB, A2, A3, M, N, W);
  
   /* Begin Method */
   for(i=0; i<M; i++){
      for(j=0; j<N; j++){
         /* step 1. Determine the local window*/      
         if(i < W) {
            rand1a = i;
            rand1b = W;
         }
         else {
              if (i>M-W-1){
               rand1a = W;
               rand1b = M-i-1;
            }
            else{
               rand1a = W;
               rand1b = W;
            }
         }

         
         if(j < W) {
            rand2a = j;
            rand2b = W;
         }
         else {
            if (j > N-W-1){
               rand2a = W;
               rand2b = N-j-1;
            }
            else{
               rand2a = W;
               rand2b = W;
            }
         }
         /* end step 1. */      
         
         minR =  255; minG =  255; minB =  255;
         maxR = -255; maxG = -255; maxB = -255;
         
         minRG =  511; minRB =  511; minGB =  511;
         maxRG = -511; maxRB = -511; maxGB = -511;
          
         histRG[(int)(A1[i][j]-A2[i][j]+255)] = histRG[(int)(A1[i][j]-A2[i][j]+255)] + 1;
         histRB[(int)(A1[i][j]-A3[i][j]+255)] = histRB[(int)(A1[i][j]-A3[i][j]+255)] + 1;
         histGB[(int)(A2[i][j]-A3[i][j]+255)] = histGB[(int)(A2[i][j]-A3[i][j]+255)] + 1;
         
  	     if((noiseR[i][j] > 0) || (noiseG[i][j] > 0)) NhistRG[(int)(A1[i][j]-A2[i][j])+255] =  NhistRG[(int)(A1[i][j]-A2[i][j])+255] + 1;
	     if((noiseR[i][j] > 0) || (noiseB[i][j] > 0)) NhistRB[(int)(A1[i][j]-A3[i][j])+255] =  NhistRB[(int)(A1[i][j]-A3[i][j])+255] + 1;
	     if((noiseG[i][j] > 0) || (noiseB[i][j] > 0)) NhistGB[(int)(A2[i][j]-A3[i][j])+255] =  NhistGB[(int)(A2[i][j]-A3[i][j])+255] + 1;

  	     if((noiseR[i][j] < 0.2) && (noiseG[i][j] < 0.2)) OhistRG[(int)(A1[i][j]-A2[i][j])+255] =  OhistRG[(int)(A1[i][j]-A2[i][j])+255] + 1;
	     if((noiseR[i][j] < 0.2) && (noiseB[i][j] < 0.2)) OhistRB[(int)(A1[i][j]-A3[i][j])+255] =  OhistRB[(int)(A1[i][j]-A3[i][j])+255] + 1;
	     if((noiseG[i][j] < 0.2) && (noiseB[i][j] < 0.2)) OhistGB[(int)(A2[i][j]-A3[i][j])+255] =  OhistGB[(int)(A2[i][j]-A3[i][j])+255] + 1;

         for (k=i-rand1a; k<=i+rand1b; k++){
	        for (l=j-rand2a; l<=j+rand2b; l++){
	           if ((A1[k][l]-A2[k][l]) < minRG) minRG = (A1[k][l]-A2[k][l]);
	           if ((A1[k][l]-A2[k][l]) > maxRG) maxRG = (A1[k][l]-A2[k][l]);
	           
	           if ((A1[k][l]-A3[k][l]) < minRB) minRB = (A1[k][l]-A3[k][l]);
	           if ((A1[k][l]-A3[k][l]) > maxRB) maxRB = (A1[k][l]-A3[k][l]);
	           
	           if ((A2[k][l]-A3[k][l]) < minGB) minGB = (A2[k][l]-A3[k][l]);
	           if ((A2[k][l]-A3[k][l]) > maxGB) maxGB = (A2[k][l]-A3[k][l]);
            }
         }
      }
   }
   
   somRG = 0; somRB = 0; somGB = 0; 
   for (i=0; i<511; i++){
      somRG += (double) OhistRG[i];
      somRB += (double) OhistRB[i];
      somGB += (double) OhistGB[i];
   }

   
   HDKRG = 0; HDKRB = 0; HDKGB = 0; 
   HMDRG = 0; HMDRB = 0; HMDGB = 0; 
   HBRRG = 0; HBRRB = 0; HBRGB = 0; 
     
   
   for (i=0; i<511; i++){
      OhistRG[i] = OhistRG[i]/somRG;
      if (i<=240) HDKRG += ((histRG[i] - NhistRG[i])/somRG);
      if ((i>240) && (i<=290)) HMDRG += ((histRG[i] - NhistRG[i])/somRG);
      if (i<=290) HBRRG += ((histRG[i] - NhistRG[i])/somRG);
      
      OhistRB[i] = OhistRB[i]/somRB;
      if (i<=240) HDKRB += ((histRB[i] - NhistRB[i])/somRB);
      if ((i>240) && (i<=290)) HMDRB += ((histRB[i] - NhistRB[i])/somRB);
      if (i<=290) HBRRB += ((histRB[i] - NhistRB[i])/somRB);

      OhistGB[i] = OhistGB[i]/somGB;
      if (i<=240) HDKGB += ((histGB[i] - NhistGB[i])/somGB);
      if ((i>240) && (i<=290)) HMDGB += ((histGB[i] - NhistGB[i])/somGB);
      if (i<=290) HBRGB += ((histGB[i] - NhistGB[i])/somGB);
   }
   
   
   C_DKRG = 0; C_DKRB = 0; C_DKGB = 0; 
   C_MDRG = 0; C_MDRB = 0; C_MDGB = 0; 
   C_BRRG = 0; C_BRRB = 0; C_BRGB = 0; 
   
   mass_DKRG = HDKRG;   mass_BRRG = HBRRG;   mass_MDRG = HMDRG;
   mass_DKRB = HDKRB;   mass_BRRB = HBRRB;   mass_MDRB = HMDRB;
   mass_DKGB = HDKGB;   mass_BRGB = HBRGB;   mass_MDGB = HMDGB;

   for (i=0; i<511; i++){
      if (i<=240)  C_DKRG += (((double)i)/510.0)*(OhistRG[i]/HDKRG);
      if ((i>240) && (i<=290))  C_MDRG += (((double)i)/510.0)*(OhistRG[i]/HMDRG);
      if (i>290)  C_BRRG += (((double)i)/510.0)*(OhistRG[i]/HBRRG);

      if (i<=240)  C_DKRB += (((double)i)/510.0)*(OhistRB[i]/HDKRB);
      if ((i>240) && (i<=290))  C_MDRB += (((double)i)/510.0)*(OhistRB[i]/HMDRB);
      if (i>290)  C_BRRB += (((double)i)/510.0)*(OhistRB[i]/HBRRB);
      
      if (i<=240)  C_DKGB += (((double)i)/510.0)*(OhistGB[i]/HDKGB);
      if ((i>240) && (i<=290))  C_MDGB += (((double)i)/510.0)*(OhistGB[i]/HMDGB);
      if (i>290)  C_BRGB += (((double)i)/510.0)*(OhistGB[i]/HBRGB);
   }   
   
   aDkRG = mass_DKRG; aDkRB = mass_DKRB; aDkGB = mass_DKGB;
   aBrRG = mass_BRRG; aBrRB = mass_BRRB; aBrGB = mass_BRGB;
   aMdRG = mass_MDRG; aMdRB = mass_MDRB; aMdGB = mass_MDGB;
   cDkRG = C_DKRG; cDkRB = C_DKRB; cDkGB = C_DKGB;
   cBrRG = C_BRRG; cBrRB = C_BRRB; cBrGB = C_BRGB;
   cMdRG = C_MDRG; cMdRB = C_MDRB; cMdGB = C_MDGB;
   
   // RG 
   if ((mass_DKRG >= (C_DKRG - tresR)) && ((C_DKRG - tresR)*mass_DKRG >0)){
      mass_DKRG = sqrt((C_DKRG - tresR)*mass_DKRG);
      C_DKRG = mass_DKRG + tresR;
   }
   if ((mass_BRRG >= ((1.0-tresR)-C_BRRG)) && (((1.0 - tresR)-C_BRRG)*mass_BRRG >0)){
      mass_BRRG = sqrt(((1.0 - tresR)-C_BRRG)*mass_BRRG);
      C_BRRG = -mass_BRRG + (1.0-tresR);
   }
   if (mass_MDRG >= absol(C_MDRG-tresR))
      mass_MDRG = absol(C_MDRG-tresR);
   if (mass_MDRG >= absol(C_MDRG-(1.0-tresR)))
      mass_MDRG = absol(C_MDRG-(1.0-tresR));

      
   // RB 
   if ((mass_DKRB >= (C_DKRB - tresG)) && ((C_DKRB - tresG)*mass_DKRB >0)){
      mass_DKRB = sqrt((C_DKRB - tresG)*mass_DKRB);
      C_DKRB = mass_DKRB + tresG;
   }
   if ((mass_BRRB >= ((1.0-tresG)-C_BRRB)) && (((1.0 - tresG)-C_BRRB)*mass_BRRB >0)){
      mass_BRRB = sqrt(((1.0 - tresG)-C_BRRB)*mass_BRRB);
      C_BRRB = -mass_BRRB + (1.0-tresG);
   }
   if (mass_MDRB >= absol(C_MDRB-tresG))
      mass_MDRB = absol(C_MDRB-tresG);
   if (mass_MDRB >= absol(C_MDRB-(1.0-tresG)))
      mass_MDRB = absol(C_MDRB-(1.0-tresG));
   
   // GB 
   if ((mass_DKGB >= (C_DKGB - tresB)) && ((C_DKGB - tresB)*mass_DKGB >0)){
      mass_DKGB = sqrt((C_DKGB - tresB)*mass_DKGB);
      C_DKGB = mass_DKGB + tresB;
   }
   if ((mass_BRGB >= ((1.0-tresB)-C_BRGB)) && (((1.0 - tresB)-C_BRGB)*mass_BRGB >0)){
      mass_BRGB = sqrt(((1.0 - tresB)-C_BRGB)*mass_BRGB);
      C_BRGB = -mass_BRGB + (1.0-tresB);
   }
   if (mass_MDGB >= absol(C_MDGB-tresB))
      mass_MDGB = absol(C_MDGB-tresB);
   if (mass_MDGB >= absol(C_MDGB-(1.0-tresB)))
      mass_MDGB = absol(C_MDGB-(1.0-tresB));
   
   
   aDkRG = mass_DKRG; aDkRB = mass_DKRB; aDkGB = mass_DKGB;
   aBrRG = mass_BRRG; aBrRB = mass_BRRB; aBrGB = mass_BRGB;
   aMdRG = mass_MDRG; aMdRB = mass_MDRB; aMdGB = mass_MDGB;
   cDkRG = C_DKRG; cDkRB = C_DKRB; cDkGB = C_DKGB;
   cBrRG = C_BRRG; cBrRB = C_BRRB; cBrGB = C_BRGB;
   cMdRG = C_MDRG; cMdRB = C_MDRB; cMdGB = C_MDGB;
   
   /* Begin Filter Method */
   for(i=0; i<M; i++){
      for(j=0; j<N; j++){

         /* step 1. Determine the local window*/      
         if(i < W) {
            rand1a = i;
            rand1b = W;
         }
         else {
              if (i>M-W-1){
               rand1a = W;
               rand1b = M-i-1;
            }
            else{
               rand1a = W;
               rand1b = W;
            }
         }

         
         if(j < W) {
            rand2a = j;
            rand2b = W;
         }
         else {
            if (j > N-W-1){
               rand2a = W;
               rand2b = N-j-1;
            }
            else{
               rand2a = W;
               rand2b = W;
            }
         }
         /* end step 1. */      
         
         som_DKRG = 0.0; som_MDRG = 0.0; som_BRRG = 0.0; 
         som_DKRB = 0.0; som_MDRB = 0.0; som_BRRB = 0.0; 
         som_DKGB = 0.0; som_MDGB = 0.0; som_BRGB = 0.0; 
         minR = 255; maxR = 0;
         minG = 255; maxG = 0;
         minB = 255; maxB = 0;
         for (k=i-rand1a; k<=i+rand1b; k++){
	        for (l=j-rand2a; l<=j+rand2b; l++){
	           tmp = MHAF( (A1[k][l]-A2[k][l]+255)/510.0, aDkRG, bDkRG, cDkRG, 1, noiseR[k][l], noiseG[k][l]);   
	           som_DKRG += tmp;
	           tmp = MHAF( (A1[k][l]-A2[k][l]+255)/510.0, aMdRG, bMdRG, cMdRG, 1, noiseR[k][l], noiseG[k][l]);   
	           som_MDRG += tmp;
	           tmp = MHAF( (A1[k][l]-A2[k][l]+255)/510.0, aBrRG, bBrRG, cBrRG, 1, noiseR[k][l], noiseG[k][l]);   
	           som_BRRG += tmp;
	        
	           tmp = MHAF( (A1[k][l]-A3[k][l]+255)/510.0, aDkRB, bDkRB, cDkRB, 1, noiseR[k][l], noiseB[k][l]);   
	           som_DKRB += tmp;
	           tmp = MHAF( (A1[k][l]-A3[k][l]+255)/510.0, aMdRB, bMdRB, cMdRB, 1, noiseR[k][l], noiseB[k][l]);   
	           som_MDRB += tmp;
	           tmp = MHAF( (A1[k][l]-A3[k][l]+255)/510.0, aBrRB, bBrRB, cBrRB, 1, noiseR[k][l], noiseB[k][l]);   
	           som_BRRB += tmp;
	        
	           tmp = MHAF( (A2[k][l]-A3[k][l]+255)/510.0, aDkGB, bDkGB, cDkGB, 1, noiseG[k][l], noiseB[k][l]);   
	           som_DKGB += tmp;
	           tmp = MHAF( (A2[k][l]-A3[k][l]+255)/510.0, aMdGB, bMdGB, cMdGB, 1, noiseG[k][l], noiseB[k][l]);   
	           som_MDGB += tmp;
	           tmp = MHAF( (A2[k][l]-A3[k][l]+255)/510.0, aBrGB, bBrGB, cBrGB, 1, noiseG[k][l], noiseB[k][l]);   
	           som_BRGB += tmp;
	        
	           if (A1[k][l] < minR) minR = A1[k][l];
	           if (A1[k][l] > maxR) maxR = A1[k][l];
	           
	           if (A2[k][l] < minG) minG = A2[k][l];
	           if (A2[k][l] > maxG) maxG = A2[k][l];
	           
	           if (A3[k][l] < minB) minB = A3[k][l];
	           if (A3[k][l] > maxB) maxB = A3[k][l];
            }
         }
         
         if ((som_DKRG == 0) && (som_MDRG == 0) && (som_BRRG == 0)){
            for (k=i-rand1a; k<=i+rand1b; k++){
	           for (l=j-rand2a; l<=j+rand2b; l++){
	              tmp = MHAF2( (A1[k][l]-A2[k][l]+255)/510.0, aDkRG, bDkRG, cDkRG, 1, noiseRG[k][l]);   
	              som_DKRG += tmp;
	              tmp = MHAF2( (A1[k][l]-A2[k][l]+255)/510.0, aMdRG, bMdRG, cMdRG, 1, noiseRG[k][l]); 
	              som_MDRG += tmp;
	              tmp = MHAF2( (A1[k][l]-A2[k][l]+255)/510.0, aBrRG, bBrRG, cBrRG, 1, noiseRG[k][l]);  
	              som_BRRG += tmp;
	           }
	        }
         }
         
         if ((som_DKRB == 0) && (som_MDRB == 0) && (som_BRRB == 0)){
            for (k=i-rand1a; k<=i+rand1b; k++){
	           for (l=j-rand2a; l<=j+rand2b; l++){
	              tmp = MHAF2( (A1[k][l]-A3[k][l]+255)/510.0, aDkRB, bDkRB, cDkRB, 1, noiseRB[k][l]);   
	              som_DKRB += tmp;
	              tmp = MHAF2( (A1[k][l]-A3[k][l]+255)/510.0, aMdRB, bMdRB, cMdRB, 1, noiseRB[k][l]); 
	              som_MDRB += tmp;
	              tmp = MHAF2( (A1[k][l]-A3[k][l]+255)/510.0, aBrRB, bBrRB, cBrRB, 1, noiseRB[k][l]);  
	              som_BRRB += tmp;
	           }
	        }
         }
         
         if ((som_DKGB == 0) && (som_MDGB == 0) && (som_BRGB == 0)){
            for (k=i-rand1a; k<=i+rand1b; k++){
	           for (l=j-rand2a; l<=j+rand2b; l++){
	              tmp = MHAF2( (A2[k][l]-A3[k][l]+255)/510.0, aDkGB, bDkGB, cDkGB, 1, noiseGB[k][l]);   
	              som_DKGB += tmp;
	              tmp = MHAF2( (A2[k][l]-A3[k][l]+255)/510.0, aMdGB, bMdGB, cMdGB, 1, noiseGB[k][l]); 
	              som_MDGB += tmp;
	              tmp = MHAF2( (A2[k][l]-A3[k][l]+255)/510.0, aBrGB, bBrGB, cBrGB, 1, noiseGB[k][l]);  
	              som_BRGB += tmp;
	           }
	        }
         }
         
         somRG = 0; somRB = 0; somGB = 0; 
         totRG = 0; totRB = 0; totGB = 0; 
         Sum_DKRG = 0; Sum_MDRG = 0; Sum_BRRG = 0;
         Sum_DKRB = 0; Sum_MDRB = 0; Sum_BRRB = 0;
         Sum_DKGB = 0; Sum_MDGB = 0; Sum_BRGB = 0;
         for (k=i-rand1a; k<=i+rand1b; k++){
	        for (l=j-rand2a; l<=j+rand2b; l++){
	           tmp = MHAF( (A1[k][l]-A2[k][l]+255)/510.0, aDkRG, bDkRG, cDkRG, 1, noiseR[k][l], noiseG[k][l]);   
	           Sum_DKRG += (tmp/som_DKRG)*(A1[k][l]-A2[k][l]);
               tmp = MHAF( (A1[k][l]-A2[k][l]+255)/510.0, aMdRG, bMdRG, cMdRG, 1, noiseR[k][l], noiseG[k][l]);   
	           Sum_MDRG += (tmp/som_MDRG)*(A1[k][l]-A2[k][l]);
	           tmp = MHAF( (A1[k][l]-A2[k][l]+255)/510.0, aBrRG, bBrRG, cBrRG, 1, noiseR[k][l], noiseG[k][l]);   
	           Sum_BRRG += (tmp/som_BRRG)*(A1[k][l]-A2[k][l]);
	           
	           if((noiseR[k][l]!=1) && (noiseG[k][l]!=1)){
	              totRG += (1.0 - minimum(noiseR[k][l],noiseG[k][l]));
	              somRG += (A1[k][l]-A2[k][l])*(1.0 - minimum(noiseR[k][l],noiseG[k][l]));
	           }
	           
	        
	           tmp = MHAF( (A1[k][l]-A3[k][l]+255)/510.0, aDkRB, bDkRB, cDkRB, 1, noiseR[k][l], noiseB[k][l]);   
	           Sum_DKRB += (tmp/som_DKRB)*(A1[k][l]-A3[k][l]);
	           tmp = MHAF( (A1[k][l]-A3[k][l]+255)/510.0, aMdRB, bMdRB, cMdRB, 1, noiseR[k][l], noiseB[k][l]);   
	           Sum_MDRB += (tmp/som_MDRB)*(A1[k][l]-A3[k][l]);
	           tmp = MHAF( (A1[k][l]-A3[k][l]+255)/510.0, aBrRB, bBrRB, cBrRB, 1, noiseR[k][l], noiseB[k][l]);   
	           Sum_BRRB += (tmp/som_BRRB)*(A1[k][l]-A3[k][l]);
	        
	           if((noiseR[k][l]!=1) && (noiseB[k][l]!=1)){
	              totRB += (1.0 - minimum(noiseR[k][l],noiseB[k][l]));
	              somRB += (A1[k][l]-A3[k][l])*(1.0 - minimum(noiseR[k][l],noiseB[k][l]));
	           }
	           
	           
	           tmp = MHAF( (A2[k][l]-A3[k][l]+255)/510.0, aDkGB, bDkGB, cDkGB, 1, noiseG[k][l], noiseB[k][l]);   
	           Sum_DKGB += (tmp/som_DKGB)*(A2[k][l]-A3[k][l]);
	           tmp = MHAF( (A2[k][l]-A3[k][l]+255)/510.0, aMdGB, bMdGB, cMdGB, 1, noiseG[k][l], noiseB[k][l]);   
	           Sum_MDGB += (tmp/som_MDGB)*(A2[k][l]-A3[k][l]);
	           tmp = MHAF( (A2[k][l]-A3[k][l]+255)/510.0, aBrGB, bBrGB, cBrGB, 1, noiseG[k][l], noiseB[k][l]);   
	           Sum_BRGB += (tmp/som_BRGB)*(A2[k][l]-A3[k][l]);
	        
	           if((noiseG[k][l]!=1) && (noiseB[k][l]!=1)){
	              totGB += (1.0 - minimum(noiseG[k][l],noiseB[k][l]));
	              somGB += (A2[k][l]-A3[k][l])*(1.0 - minimum(noiseG[k][l],noiseB[k][l]));
	           }
	        }
	     }
	     
	     predRG = 0; predGR = 0; predRB = 0; predBR = 0; predGB = 0; predBG = 0;
	     totR = 0; totG = 0; somR = 0; somG = 0;
	     
	     if (totRG == 0){
	        somRG = 0.0;
            for (k=i-rand1a; k<=i+rand1b; k++){
	           for (l=j-rand2a; l<=j+rand2b; l++){
	              totRG += 1.0 - noiseRG[k][l];
	              somRG += (A1[k][l]-A2[k][l])*(1.0-noiseRG[k][l]);
	           }
	        }
	        if(totRG > 0){
	           predRG = somRG/totRG;
	           predGR = -predRG;
	           
	           min1 = absol(predRG-Sum_DKRG);
	           min2 = absol(predRG-Sum_MDRG);
	           min3 = absol(predRG-Sum_BRRG);
	           
	           if ((Sum_DKRG > 0.4) ||(Sum_MDRG>0.4) ||(Sum_BRRG > 0.4)){
	              if (min1 <= minimum(min2,min3)) { predRG = Sum_DKRG; predGR = -Sum_DKRG; }
	              else if (min2 <= minimum(min1,min3)){ predRG = Sum_MDRG; predGR = -Sum_MDRG; }
	              else { predRG = Sum_BRRG; predGR = -Sum_BRRG; }
               }
	        }
	        else {
	           t1 = 0; t2 = 0; t3 = 0; t4 = 0;
               for (k=i-rand1a; k<=i+rand1b; k++){
	              for (l=j-rand2a; l<=j+rand2b; l++){
	                 if ((A1[k][l] != minR) && (A1[k][l] != maxR)){ somR += A1[k][l]; totR += 1; }
	                 if ((A2[k][l] != minG) && (A2[k][l] != maxG)){ somG += A2[k][l]; totG += 1; }
	                 if (A1[k][l]==minR) t2++;
	                 if (A1[k][l]==maxR) t1++;
	                 if (A2[k][l]==minG) t4++;
	                 if (A2[k][l]==maxG) t3++;
	              }
  	           }
  	           if(totR == 0){
  	              if (t1>t2) hlp1 = maxR;
  	              else if (t1<t2) hlp1 = minR;
  	              else hlp1 = (minR+maxR)/2;
  	           }
  	           else hlp1 = somR/totR;
	        
  	           if(totG == 0){
  	              if (t3>t4) hlp2 = maxG;
  	              else if (t3<t4) hlp2 = minG;
  	              else hlp2 = (minG+maxG)/2;
  	           }
  	           else hlp2 = somG/totG;
  	           
  	           predRG = hlp1 - hlp2;
  	           predGR = -hlp1 + hlp2;
	        }
	     }
	     else {
	        predRG = somRG/totRG;
	        predGR = -predRG;
	        
	        min1 = absol(predRG-Sum_DKRG);
	        min2 = absol(predRG-Sum_MDRG); 
	        min3 = absol(predRG-Sum_BRRG);

	        if (min1 <= minimum(min2,min3)) { predRG = Sum_DKRG; predGR = -Sum_DKRG; }
	        else if (min2 <= minimum(min1,min3)){ predRG = Sum_MDRG; predGR = -Sum_MDRG; }
	        else { predRG = Sum_BRRG; predGR = -Sum_BRRG; }
	     }
	     
	     
	     
	     
	     totR = 0; totB = 0; somR = 0; somB = 0;
	     if (totRB == 0){
	        somRB = 0.0;
            for (k=i-rand1a; k<=i+rand1b; k++){
	           for (l=j-rand2a; l<=j+rand2b; l++){
	              totRB += 1.0 - noiseRB[k][l];
	              somRB += (A1[k][l]-A3[k][l])*(1.0-noiseRB[k][l]);
	           }
	        }
	        if(totRB > 0){
	           predRB = somRB/totRB;
	           predBR = -predRB;
	           
	           min1 = absol(predRB - Sum_DKRB);
	           min2 = absol(predRB - Sum_MDRB);
	           min3 = absol(predRB - Sum_BRRB);
	           	          
               if ((Sum_DKRB > 0.4) ||(Sum_MDRB>0.4) ||(Sum_BRRB > 0.4)){
 	              if (min1 <= minimum(min2,min3)) { predRB = Sum_DKRB; predBR = -Sum_DKRB; }
	              else if (min2 <= minimum(min1,min3)){ predRB = Sum_MDRB; predBR = -Sum_MDRB; }
	              else { predRB = Sum_BRRB; predBR = -Sum_BRRB; }
               }
	        }
	        else {
	           t1 = 0; t2 = 0; t3 = 0; t4 = 0;
               for (k=i-rand1a; k<=i+rand1b; k++){
	              for (l=j-rand2a; l<=j+rand2b; l++){
	                 if ((A1[k][l] != minR) && (A1[k][l] != maxR)){ somR += A1[k][l]; totR += 1; }
	                 if ((A3[k][l] != minB) && (A3[k][l] != maxB)){ somB += A3[k][l]; totB += 1; }
	                 if (A1[k][l]==minR) t2++;
	                 if (A1[k][l]==maxR) t1++;
	                 if (A3[k][l]==minB) t4++;
	                 if (A3[k][l]==maxB) t3++;
	              }
  	           }
  	           if(totR == 0){
  	              if (t1>t2) hlp1 = maxR;
  	              else if (t1<t2) hlp1 = minR;
  	              else hlp1 = (minR+maxR)/2;
  	           }
  	           else hlp1 = somR/totR;
	        
  	           if(totB == 0){
  	              if (t3>t4) hlp2 = maxB;
  	              else if (t3<t4) hlp2 = minB;
  	              else hlp2 = (minB+maxB)/2;
  	           }
  	           else hlp2 = somB/totB;
  	           
  	           predRB = hlp1 - hlp2;
  	           predBR = -hlp1 + hlp2;
	        }
	     }
	     else {
	        predRB = somRB/totRB;
	        predBR = -predRB;
	        
	        min1 = absol(predRB-Sum_DKRB);
	        min2 = absol(predRB-Sum_MDRB); 
	        min3 = absol(predRB-Sum_BRRB);

	        if (min1 <= minimum(min2,min3)) { predRB = Sum_DKRB; predBR = -Sum_DKRB; }
	        else if (min2 <= minimum(min1,min3)){ predRB = Sum_MDRB; predBR = -Sum_MDRB; }
	        else { predRB = Sum_BRRB; predBR = -Sum_BRRB; }
	     }
         
	     totG = 0; totB = 0; somG = 0; somB = 0;
	     if (totGB == 0){
	        somGB = 0.0;
            for (k=i-rand1a; k<=i+rand1b; k++){
	           for (l=j-rand2a; l<=j+rand2b; l++){
	              totGB += 1.0 - noiseGB[k][l];
	              somGB += (A2[k][l]-A3[k][l])*(1.0-noiseGB[k][l]);
	           }
	        }
            

            if(totGB > 0){
	           predGB = somGB/totGB;
	           predBG = -predGB;
	           
	           min1 = absol(predGB - Sum_DKGB);
	           min2 = absol(predGB - Sum_MDGB);
	           min3 = absol(predGB - Sum_BRGB);
	           if ((Sum_DKGB > 0.4) ||(Sum_MDGB>0.4) ||(Sum_BRGB > 0.4)){
	              if (min1 <= minimum(min2,min3)) { predGB = Sum_DKGB; predBG = -Sum_DKGB; }
	              else if (min2 <= minimum(min1,min3)){ predGB = Sum_MDGB; predBG = -Sum_MDGB; }
	              else { predGB = Sum_BRGB; predBG = -Sum_BRGB; }
               }
	        }
	        else {
	           t1 = 0; t2 = 0; t3 = 0; t4 = 0;
               for (k=i-rand1a; k<=i+rand1b; k++){
	              for (l=j-rand2a; l<=j+rand2b; l++){
	                 if ((A2[k][l] != minG) && (A2[k][l] != maxG)){ somG += A2[k][l]; totG += 1; }
	                 if ((A3[k][l] != minB) && (A3[k][l] != maxB)){ somB += A3[k][l]; totB += 1; }
	                 if (A2[k][l]==minG) t2++;
	                 if (A2[k][l]==maxG) t1++;
	                 if (A3[k][l]==minB) t4++;
	                 if (A3[k][l]==maxB) t3++;
	              }
  	           }
               
  	           if(totG == 0){
  	              if (t1>t2) hlp1 = maxG;
  	              else if (t1<t2) hlp1 = minG;
  	              else hlp1 = (minG+maxG)/2;
  	           }
  	           else hlp1 = somG/totG;
	        
  	           if(totB == 0){
  	              if (t3>t4) hlp2 = maxB;
  	              else if (t3<t4) hlp2 = minB;
  	              else hlp2 = (minB+maxB)/2;
  	           }
  	           else hlp2 = somB/totB;
  	           
  	           predGB = hlp1 - hlp2;
  	           predBG = -hlp1 + hlp2;
	        }
	     }
	     else {
	        predGB = somGB/totGB;
	        predBG = -predGB;
	        
	        min1 = absol(predGB-Sum_DKGB);
	        min2 = absol(predGB-Sum_MDGB); 
	        min3 = absol(predGB-Sum_BRGB);

	        if (min1 <= minimum(min2,min3)) { predGB = Sum_DKGB; predBG = -Sum_DKGB; }
	        else if (min2 <= minimum(min1,min3)){ predGB = Sum_MDGB; predBG = -Sum_MDGB; }
	        else { predGB = Sum_BRGB; predBG = -Sum_BRGB; }
	     }
	     
	     somR = 0; somG = 0; somB = 0;
	     totR = 0; totG = 0; totB = 0;
	     resR = 0; resG = 0; resB = 0;
         for (k=i-rand1a; k<=i+rand1b; k++){
	        for (l=j-rand2a; l<=j+rand2b; l++){
	           totR += (1.0 - noiseR[k][l]);
	           totG += (1.0 - noiseG[k][l]);
	           totB += (1.0 - noiseB[k][l]);
	           somR += (1.0 - noiseR[k][l])*A1[k][l];
	           somG += (1.0 - noiseG[k][l])*A2[k][l];
	           somB += (1.0 - noiseB[k][l])*A3[k][l];
	        }
  	     }
  	     
         
  	     //RED
  	     hlp1 = 0; tel = 0; tel1 = 0; tel2 = 0;
  	     if(totR == 0){
            for (k=i-rand1a; k<=i+rand1b; k++){
	           for (l=j-rand2a; l<=j+rand2b; l++){
	              if((A1[k][l]!=minR) && (A1[k][l]!=maxR)) { hlp1 += A1[k][l]; tel += 1; }
	              else if (A1[k][l] == minR) tel1 += 1;
	              else tel2 += 1;
	           }
	        }

            if (tel == 0){
               if (tel1 > tel2) resR = minR;
               else if (tel1 < tel2) resR = maxR;
               else resR = A1[i][j];
            }
            else resR = hlp1/tel;
  	     }
  	     else resR = somR/totR;


  	     //GREEN
  	     hlp1 = 0; tel = 0; tel1 = 0; tel2 = 0;
  	     if(totG == 0){
            for (k=i-rand1a; k<=i+rand1b; k++){
	           for (l=j-rand2a; l<=j+rand2b; l++){
	              if((A2[k][l]!=minG) && (A2[k][l]!=maxG)) { hlp1 += A2[k][l]; tel += 1; }
	              else if (A2[k][l] == minG) tel1 += 1;
	              else tel2 += 1;
	           }
	        }
            if (tel == 0){
               if (tel1 > tel2) resG = minG;
               else if (tel1 < tel2) resG = maxG;
               else resG = A2[i][j];
            }
            else resG = hlp1/tel;
  	     }
  	     else resG = somG/totG;

         
         //BLUE
  	     hlp1 = 0; tel = 0; tel1 = 0; tel2 = 0;
  	     if(totB == 0){
            for (k=i-rand1a; k<=i+rand1b; k++){
	           for (l=j-rand2a; l<=j+rand2b; l++){
	              if((A3[k][l]!=minB) && (A3[k][l]!=maxB)) { hlp1 += A3[k][l]; tel += 1; }
	              else if (A3[k][l] == minB) tel1 += 1;
	              else tel2 += 1;
	           }
	        }
            if (tel == 0){
               if (tel1 > tel2) resB = minB;
               else if (tel1 < tel2) resB = maxB;
               else resB = A3[i][j];
            }
            else resB = hlp1/tel;
  	     }
  	     else resB = somB/totB;
  	     
  	     
  	     // Filtering RED pixel at position (i,j)
  	     if (noiseR[i][j] > 0){
  	        if ((noiseG[i][j]  > 0.0) && (noiseB[i][j]  > 0.0)){
  	           hlp1 = resR;
  	           out1[i+j*M]  = hlp1;
  	        }
  	        else if (noiseG[i][j] > 0){
  	           hlp1 = A3[i][j] + predRB;
  	           hlp1 = minimum(255,maximum(hlp1,0));
  	           out1[i+j*M]  = hlp1;
  	        }
  	        else if (noiseB[i][j] > 0){
  	           hlp1 = A2[i][j] + predRG;
  	           hlp1 = minimum(255,maximum(hlp1,0));
  	           out1[i+j*M]  = hlp1;
  	        }
  	        else {
  	           hlp1 = (A2[i][j] + predRG + A3[i][j] + predRB)/2.0;
  	           hlp1 = minimum(255,maximum(hlp1,0));
  	           out1[i+j*M]  = hlp1;
  	        }
  	     }
  	     else out1[i+j*M] = A1[i][j];


  	     // Filtering GREEN pixel at position (i,j)
  	     if (noiseG[i][j] > 0){
  	        if ((noiseR[i][j] > 0) && (noiseB[i][j] > 0)){
  	           hlp1 = resG;
  	           out2[i+j*M]  = hlp1;
  	        }
  	        else if (noiseR[i][j] > 0){
  	           hlp1 = A3[i][j] + predGB;
  	           hlp1 = minimum(255,maximum(hlp1,0));
  	           out2[i+j*M]  = hlp1;
  	        }
  	        else if (noiseB[i][j] > 0){
  	           hlp1 = A1[i][j] + predGR;
  	           hlp1 = minimum(255,maximum(hlp1,0));
  	           out2[i+j*M]  = hlp1;
  	        }
  	        else {
  	           hlp1 = (A1[i][j] + predGR + A3[i][j] + predGB)/2.0;
  	           hlp1 = minimum(255,maximum(hlp1,0));
  	           out2[i+j*M]  = hlp1;
  	        }
  	     }
  	     else out2[i+j*M] = A2[i][j];  	     
  	     
  	     // Filtering BLUE pixel at position (i,j)
  	     if (noiseB[i][j] > 0){
  	        if ((noiseR[i][j] >0) && (noiseG[i][j] > 0)){
  	           hlp1 = resB;
  	           out3[i+j*M]  = hlp1;
  	        }
  	        else if (noiseR[i][j] > 0){
  	           hlp1 = A2[i][j] + predBG;
  	           hlp1 = minimum(255,maximum(hlp1,0));
  	           out3[i+j*M]  = hlp1;
  	        }
  	        else if (noiseG[i][j] > 0){
  	           hlp1 = A1[i][j] + predBR;
  	           hlp1 = minimum(255,maximum(hlp1,0));
  	           out3[i+j*M]  = hlp1;
  	        }
  	        else {
  	           hlp1 = (A1[i][j] + predBR + A2[i][j] + predBG)/2.0;
  	           hlp1 = minimum(255,maximum(hlp1,0));
  	           out3[i+j*M]  = hlp1;
  	        }
  	     }
  	     else out3[i+j*M] = A3[i][j];
      }
   }

   for(i=0;i<M;i++)  free(RG[i]);
   free(RG);    
   for(i=0;i<M;i++)  free(RB[i]);
   free(RB);    
   for(i=0;i<M;i++)  free(GB[i]);
   free(GB);    

   for(i=0;i<M;i++)  free(noiseRG[i]);
   free(noiseRG);    
   for(i=0;i<M;i++)  free(noiseRB[i]);
   free(noiseRB);    
   for(i=0;i<M;i++)  free(noiseGB[i]);
   free(noiseGB);    

   free(histRG); free(histRB); free(histGB); 
   free(NhistRG); free(NhistRB); free(NhistGB);    
   free(OhistRG); free(OhistRB); free(OhistGB);    
}  /* End of callFuzzyShrink */


#define Im1      prhs[0]
#define Im2      prhs[1]
#define Im3      prhs[2]
#define Nm1      prhs[3]
#define Nm2      prhs[4]
#define Nm3      prhs[5]
#define WSIZE    prhs[6]

#define Out1 plhs[0]
#define Out2 plhs[1]
#define Out3 plhs[2]

/**
*  The interaction with Matlab (mex):
*        nlhs = amount of output arguments (= 1)
*        nrhs = amount of input arguments (= 3)
*     *plhs[] = link to the output 
*     *prhs[] = link to the input 
*
**/
void mexFunction( int nlhs, mxArray  *plhs[], int nrhs, const mxArray  *prhs[] ) {
    int row, col, i, M, N, K, W;
    double **out1, **out2, **out3, **A1, **A2, **A3,**noiseR, **noiseG, **noiseB;
    
    if (nlhs!=3)
        mexErrMsgTxt("It requires three output arguments only [RED GREEN BLUE].");
    if (nrhs!=7)
       mexErrMsgTxt("this method requires 7 input argument [A1 A2 A3 noiseR noiseG noiseB Wsize]");

    /* Get input values */  
    M = mxGetM(Im1);
    N = mxGetN(Im1);
    W = mxGetScalar(WSIZE);

    /**
    * Allocate memory for return matrices 
    **/
    Out1 = mxCreateDoubleMatrix(M, N, mxREAL);  
    out1 = mxGetPr(Out1);

    Out2 = mxCreateDoubleMatrix(M, N, mxREAL);  
    out2 = mxGetPr(Out2);

    Out3 = mxCreateDoubleMatrix(M, N, mxREAL);  
    out3 = mxGetPr(Out3);


    /**
    * Dynamic allocation of memory for the input array
    **/
    A1 = malloc(M*sizeof(int));
    for(i=0;i<M;i++)
      A1[i] = malloc(N*sizeof(double));

    A2 = malloc(M*sizeof(int));
    for(i=0;i<M;i++)
      A2[i] = malloc(N*sizeof(double));

    A3 = malloc(M*sizeof(int));
    for(i=0;i<M;i++)
      A3[i] = malloc(N*sizeof(double));

    noiseR = malloc(M*sizeof(int));
    for(i=0;i<M;i++)
      noiseR[i] = malloc(N*sizeof(double));

    noiseG = malloc(M*sizeof(int));
    for(i=0;i<M;i++)
      noiseG[i] = malloc(N*sizeof(double));
    
    noiseB = malloc(M*sizeof(int));
    for(i=0;i<M;i++)
      noiseB[i] = malloc(N*sizeof(double));

     /**
     * Convert ARRAY_IN and INPUT_MASK to 2x2 C arrays (MATLAB stores a two-dimensional matrix 
     * in memory as a one-dimensional array) 
     ***/
     for (col=0; col < N; col++)
         for (row=0; row < M; row++) {
             A1[row][col] = (mxGetPr(Im1))[row+col*M];
	      }
	      
     for (col=0; col < N; col++)
         for (row=0; row < M; row++) {
             A2[row][col] = (mxGetPr(Im2))[row+col*M];
	      }
	      
     for (col=0; col < N; col++)
         for (row=0; row < M; row++) {
             A3[row][col] = (mxGetPr(Im3))[row+col*M];
	      }
	      
	      
     for (col=0; col < N; col++)
         for (row=0; row < M; row++) {
             noiseR[row][col] = (mxGetPr(Nm1))[row+col*M];
	      }
	      
     for (col=0; col < N; col++)
         for (row=0; row < M; row++) {
             noiseG[row][col] = (mxGetPr(Nm2))[row+col*M];
	      }
	      
     for (col=0; col < N; col++)
         for (row=0; row < M; row++) {
             noiseB[row][col] = (mxGetPr(Nm3))[row+col*M];
	      }
	      
	      
    /* Call callFuzzyShrink function */ 
    callHFC1c(A1,A2,A3,noiseR,noiseG,noiseB,out1,out2,out3,M,N,W);

    for(i=0;i<M;i++)  free(A1[i]);
    free(A1); 
    for(i=0;i<M;i++)  free(A2[i]);
    free(A2); 
    for(i=0;i<M;i++)  free(A3[i]);
    free(A3); 
    for(i=0;i<M;i++)  free(noiseR[i]);
    free(noiseR); 
    for(i=0;i<M;i++)  free(noiseG[i]);
    free(noiseG); 
    for(i=0;i<M;i++)  free(noiseB[i]);
    free(noiseB); 
}
/* end mexFcn*/