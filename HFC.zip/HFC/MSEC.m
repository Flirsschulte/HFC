function result = MSE3corect(A,B,rand);
[mA nA,d] = size(A);
[mB nB,d] = size(B);
if (mA ~= mB | nA ~= nB)
   error('Arrays A and B must have the same size');
end;
A = double(A);
B = double(B);
resultR = 0;
resultG = 0;
resultB = 0;
% we laten de rand buiten beschouwing
for i = 1+rand:mA-rand
   for j = 1+rand:nA-rand
      resultR = resultR + (A(i,j,1) - B(i,j,1))^2;
      resultG = resultG + (A(i,j,2) - B(i,j,2))^2;
      resultB = resultB + (A(i,j,3) - B(i,j,3))^2;
   end;
end;
resultR = resultR / ((mA-2*rand)*(nA-2*rand));
resultG = resultG / ((mA-2*rand)*(nA-2*rand));
resultB = resultB / ((mA-2*rand)*(nA-2*rand));
result = 0;
result = (resultR+resultG+resultB)/3;
