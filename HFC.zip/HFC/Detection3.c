
/**************************************************************************
% HFC: histogram fuzzy colour filter (for random valued impulse noise)
% Note: Matlab 7.1 is used (deviation against 0 is solved here)
%
%  The paper of the HFC is proposed in: 
%
%  Stefan Schulte, Val�rie De Witte, , Mike Nachtegael
%  Dietrich Van Der Weken and  Etienne E. Kerre:
%  Histogram-based fuzzy colour filter for image restoration,
%  Image and Vision Computing  in press. 2007
%
% Stefan Schulte (stefan.schulte@Ugent.be):
% Last modified: 21/08/06
%
%**************************************************************************/

#include "mex.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

double LARGE (double x, double p1, double p2) {
   double res = 0.0;
   if ((x > p1) && (x < p2))   res = (x-p1)/(p2-p1);
   else if (x > p2)            res = 1.0;
   else                        res = 0.0;
   return res;
}

double absol(double a) {
   double b;
   if(a<0)   b=-a;
   else   b=a;
   return b;
}

double minimum(double a, double b) {
   double x;
   if(a<=b)   x = a;
   else   x=b;
   return x;
}

double maximum(double a, double b) {
   double x;
   if(a<=b)   x = b;
   else   x=a;
   return x;
}

/**************************************************************************************
*  The main function 
***************************************************************************************/
void CALL_MEM2(double **A1,double W,double **mem,double *out,int M, int N) { 
   int i,j,k,l,pos,posD, tel;   
   double tmp, hlp,diff1, diff2, maxi, mini, maxD, lg;
   double *H1;
   
   int rand1a = 0;
   int rand1b = 0;
   int rand2a = 0;
   int rand2b = 0;
   
   int rand3a = 0;
   int rand3b = 0;
   int rand4a = 0;
   int rand4b = 0;
   
   H1 = malloc((2*W+1)*(2*W+1)*sizeof(double));   
   for (i=0; i<(2*W+1)*(2*W+1);i++) H1[i] = 0;

   
   for (j=0; j<N;j++)
       for (i=0; i<N;i++){
          pos =  i+j*N;
          out[pos] = 0;
       }
   for(i=0; i<M; i++){
      for(j=0; j<N; j++){
         if (mem[i][j] < 1.0){
             /* step 1. Determine the local window*/      
             if(i < W) {
               rand1a = i;
               rand1b = W;
            }
            else {
              if (i>M-W-1){
                rand1a = W;
                rand1b = M-i-1;
              }
              else{
                rand1a = W;
                rand1b = W;
             }
           }

           if(j < W) {
              rand2a = j;
              rand2b = W;
           }
           else {
              if (j > N-W-1){
                 rand2a = W;
                 rand2b = N-j-1;
              }
              else{
                 rand2a = W;
                 rand2b = W;
              }
           }
             
            tel = 0;
          
            for(k=-rand1a; k<=rand1b; k++){ 
               for(l=-rand2a; l<=rand2b; l++){ 
                  if ((k==0)&&(l==0)) continue;
                  else if (mem[i+k][j+l] < 1.0){
                     tmp = A1[i+k][j+l];
                     for (pos = 0; pos<tel; pos++){
                         if (tmp < H1[pos]){
                             hlp = H1[pos];
                             H1[pos] = tmp;
                             tmp = hlp;
                         }
                     }
                     H1[tel] = tmp;
                     tel++;
                  }
               }
            }
            H1[tel] = A1[i][j];
            if (tel == 0) continue;
            
            mini = H1[0];  maxi = H1[tel-1];
            if ((H1[tel]<=mini) || (H1[tel]>=maxi)){
                diff1 = 0; diff2 = 0;
                if (H1[tel]<= mini) diff1 = maxi - H1[tel];
                else  diff1 = H1[tel] - mini;
                diff2 = maxi - mini;
                lg = LARGE (diff1, 1.09*diff2, 1.35*diff2);
                out[(int)(i+j*M)] = maximum(lg,mem[i][j]);
                
                if ((out[(i+j*M)]>0.6)&&(tel>=2)){
                    maxD = 0; posD = 0;
                    for (k = 0; k<tel-2; k++){
                        if ((H1[k+1]-H1[k])>maxD){
                            maxD = H1[k+1]-H1[k];
                            posD = k;
                        }
                    }
                    if ((maxi = H1[posD])&&(posD!=0)) maxi = H1[posD-1];
                    if ((mini = H1[posD])&&(posD!=tel-1)) mini = H1[posD+1];
                    diff1 = 0; diff2 = 0;
                    if (H1[tel]<= mini) diff1 = maxi - H1[tel];
                    else  diff1 = H1[tel] - mini;
                    diff2 = maxi - mini;
                    lg = LARGE (diff1, 1.09*diff2, 1.35*diff2);
                    out[(int)(i+j*M)] = maximum(lg,out[(int)(i+j*M)]);
                }
            }
            else out[(int)(i+j*M)] = mem[i][j];
         }
         else  out[(int)(i+j*M)] = mem[i][j];
      }
   }
   free(H1); 
}  


#define Im1      prhs[0]
#define MEM      prhs[1]
#define WSIZE    prhs[2]

#define OUT plhs[0]

/**
*  The interaction with Matlab (mex):
*        nlhs = amount of output arguments (= 1)
*        nrhs = amount of input arguments (= 3)
*     *plhs[] = link to the output 
*     *prhs[] = link to the input 
*
**/
void mexFunction( int nlhs, mxArray  *plhs[], int nrhs, const mxArray  *prhs[] ) {
    int row, col, i, M, N,W;
    double **mem, **out, **A1;
    
    if (nlhs!=1)
        mexErrMsgTxt("It requires one output arguments only [M1].");
    if (nrhs!=3)
       mexErrMsgTxt("this method requires three input argument [Im1,MEM,WSIZE]");

    /* Get input values */  
    M = mxGetM(Im1);
    N = mxGetN(Im1);
    W = mxGetScalar(WSIZE);

    
    /**
    * Allocate memory for return matrices 
    **/
    OUT = mxCreateDoubleMatrix(M, N, mxREAL);  
    out = mxGetPr(OUT);

    /**
    * Dynamic allocation of memory for the input array
    **/
    A1 = malloc(M*sizeof(int));
    for(i=0;i<M;i++)
      A1[i] = malloc(N*sizeof(double));

    mem = malloc(M*sizeof(int));
    for(i=0;i<M;i++)
      mem[i] = malloc(N*sizeof(double));

     /**
     * Convert ARRAY_IN and INPUT_MASK to 2x2 C arrays (MATLAB stores a two-dimensional matrix 
     * in memory as a one-dimensional array) 
     ***/
     for (col=0; col < N; col++)
         for (row=0; row < M; row++) {
             A1[row][col] = (mxGetPr(Im1))[row+col*M];
	      }
	      
     for (col=0; col < N; col++)
         for (row=0; row < M; row++) {
             mem[row][col] = (mxGetPr(MEM))[row+col*M];
	      }
	      
    
    CALL_MEM2(A1,W,mem,out,M,N);

    for(i=0;i<M;i++)  free(A1[i]);
    free(A1); 
    for(i=0;i<M;i++)  free(mem[i]);
    free(mem); 
}
/* end mexFcn*/