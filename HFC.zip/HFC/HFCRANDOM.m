
%**************************************************************************
% HFC: histogram fuzzy colour filter (for random valued impulse noise)
% Note: Matlab 7.1 is used (deviation against 0 is solved here)
%
%  The paper of the HFC is proposed in: 
%
%  Stefan Schulte, Val�rie De Witte, , Mike Nachtegael
%  Dietrich Van Der Weken and  Etienne E. Kerre:
%  Histogram-based fuzzy colour filter for image restoration,
%  Image and Vision Computing  in press. 2007
%
% Stefan Schulte (stefan.schulte@Ugent.be):
% Last modified: 21/08/06
%
% Inputs:  A = the noisy input image
%          O = the original noise-free image
% Outputs:  Fs = the filtered image 
%**************************************************************************

function Fs = HFCRANDOM(A,O)
   [M,N,DIM] = size(A);
   A1 = double(A(:,:,1));
   A2 = double(A(:,:,2));
   A3 = double(A(:,:,3));
   WSIZE = 1;
 
   % neighbourhood size 
   WindowSize  = 2;
   WindowSize2 = 3;
   
   % Red component
   memR = Detection2(A1,WindowSize2,WindowSize);
   noiseR = Detection3(A1,memR,1); 

   % Green component
   memG = Detection2(A2,WindowSize2,WindowSize);
   noiseG = Detection3(A2,memG,1); 
 
   % Blue component
   memB = Detection2(A3,WindowSize2,WindowSize);
   noiseB = Detection3(A3,memB,1); 

   [F1,F2,F3] = HFC2(A1, A2, A3,noiseR,noiseG,noiseB,WSIZE);

   Fs(:,:,1) = F1;   
   Fs(:,:,2) = F2;   
   Fs(:,:,3) = F3;   
