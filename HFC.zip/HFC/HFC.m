
%**************************************************************************
% HFC: histogram fuzzy colour filter (for fixed impulse noise)
% Note: Matlab 7.1 is used (deviation against 0 is solved here)
%
%  The paper of the HFC is proposed in: 
%
%  Stefan Schulte, Val�rie De Witte, , Mike Nachtegael
%  Dietrich Van Der Weken and  Etienne E. Kerre:
%  Histogram-based fuzzy colour filter for image restoration,
%  Image and Vision Computing  in press. 2007
%
% Stefan Schulte (stefan.schulte@Ugent.be):
% Last modified: 21/08/06
%
% Inputs:  A = the noisy input image
%          O = the original noise-free image
% Outputs:  Fs = the filtered image 
%**************************************************************************


function Fs = HFC(A,O)
   disp(sprintf('========================================='));
   disp(sprintf(' HFC: Histogram Fuzzy Colour Filter'));
   disp(sprintf(' Author: Stefan Schulte'));
   disp(sprintf(' Mail: Stefan.Schulte@Ugent.be'));
   disp(sprintf('========================================='));
   [M,N,DIM] = size(A);
   A1 = double(A(:,:,1));
   A2 = double(A(:,:,2));
   A3 = double(A(:,:,3));
   WSIZE = 1;
 
   disp(sprintf(''));
   disp(sprintf('Fixed-Value Impulse noise Reduction Method'));
   disp(sprintf(''));
   [F1,F2,F3] = HFC1(A1, A2, A3,WSIZE);

   Fs(:,:,1) = F1;   
   Fs(:,:,2) = F2;   
   Fs(:,:,3) = F3;   
   if (F1(1,1) == -1)
      disp(sprintf(''));
      disp(sprintf('Random-Value Impulse noise Reduction Method'));
      disp(sprintf(''));
      Fs = HFCRANDOM(A,O);
   end
   disp(sprintf('======================='));
   disp(sprintf('Output MSE:  %10.5f',MSEC(Fs,O,3)));
   disp(sprintf('Output PSNR: %10.5f',(log(255^2/MSEC(Fs,O,3))/log(10)*10)));
   disp(sprintf('======================='));